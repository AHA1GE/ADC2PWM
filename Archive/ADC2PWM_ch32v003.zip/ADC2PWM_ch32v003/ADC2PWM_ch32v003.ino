/*
Functions
1. After reset, output PWM_BOOT_US pulse width for BOOT_TIME_MS
2. Then read ADC and map to PWM_MIN_US...PWM_MAX_US pulse width
3. Gentle start: output ramps toward target instead of jumping
4. All pins and parameters defined for easy editing
*/

#include "CH32V003_SERVO.h"

// ---------------- Pin Definitions ----------------
#define PWM_PIN SERVO_PIN_CH1  // PD4, TIM2_CH1 (default mapping)
#define ADC_PIN PA2  // ADC input pin (ADC 0)
#define LED_PIN PD1  // active LOW

// ---------------- PWM Range ----------------
#define PWM_BOOT_US 890
#define PWM_MIN_US 1000
#define PWM_MAX_US 2000

// ---------------- Timing ----------------
#define BOOT_TIME_MS 2500  // must >2s
#define LOOP_DELAY_MS 10   // 100hz

// ---------------- Soft Start ----------------
#define RAMP_STEP_US_UP 2
#define RAMP_STEP_US_DOWN 4

// ---------------- Safety Latch ----------------
// Must pull ADC near minimum once after boot before normal mode is enabled.
#define ADC_ARM_THRESHOLD 10

// ---------------- Variables ----------------
uint16_t pwmOutput = PWM_BOOT_US;
uint16_t pwmTarget = PWM_BOOT_US;
unsigned long bootTime;
bool safetyArmed = false;
Servo myservo;

// ---------------- Setup ----------------
void setup() {
  pinMode(PWM_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, HIGH);  // turn off LED (active LOW)

  bootTime = millis();

  // attach
  myservo.attach(PWM_PIN);

  myservo.writeMicroseconds(PWM_BOOT_US);
}

// ---------------- Main Loop ----------------
void loop() {
  if (millis() - bootTime < BOOT_TIME_MS) {
    // blink the LED while in the boot period (LED is active‑LOW)
    unsigned long t = millis() - bootTime;
    if (((t / 500) % 2) == 0)
      digitalWrite(LED_PIN, LOW);
    else
      digitalWrite(LED_PIN, HIGH);

    myservo.writeMicroseconds(PWM_BOOT_US);
    delay(LOOP_DELAY_MS);
    return;
  }

  // Safety latch: require ADC minimum before enabling normal control.
  if (!safetyArmed) {
    uint16_t adc = analogRead(ADC_PIN);
    if (adc <= ADC_ARM_THRESHOLD) {
      safetyArmed = true;
      pwmTarget = PWM_MIN_US;
    }

    // Keep motor at safe boot pulse while waiting for latch condition.
    myservo.writeMicroseconds(PWM_BOOT_US);

    // Fast blink while waiting for unlock (active LOW LED).
    unsigned long t = millis();
    if (((t / 150) % 2) == 0)
      digitalWrite(LED_PIN, LOW);
    else
      digitalWrite(LED_PIN, HIGH);

    delay(LOOP_DELAY_MS);
    return;
  }

  // turn on LED after boot period
  digitalWrite(LED_PIN, LOW);

  // read ADC
  uint16_t adc = analogRead(ADC_PIN);

  // map ADC to PWM range
  pwmTarget = map(adc, 0, 1023, PWM_MIN_US, PWM_MAX_US);

  // soft ramp toward target
  if (pwmOutput < pwmTarget) {
    pwmOutput += RAMP_STEP_US_UP;
    if (pwmOutput > pwmTarget) pwmOutput = pwmTarget;
  } else if (pwmOutput > pwmTarget) {
    pwmOutput -= RAMP_STEP_US_DOWN;
    if (pwmOutput < pwmTarget) pwmOutput = pwmTarget;
  }

  myservo.writeMicroseconds(pwmOutput);

  delay(LOOP_DELAY_MS);
}