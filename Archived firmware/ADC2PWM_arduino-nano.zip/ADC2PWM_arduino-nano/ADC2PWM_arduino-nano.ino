/*
Simple AVR Arduino code

Functions
1. After reset, output 899us PWM for 2 seconds
2. Then read ADC and map to 900–2000us PWM
3. Gentle start: output ramps toward target instead of jumping
4. All pins and parameters defined for easy editing
*/

#include <Servo.h>

// ---------------- Pin Definitions ----------------
#define PWM_PIN 2
#define ADC_PIN A0
#define LED_PIN 3  // active LOW

// ---------------- PWM Range ----------------
#define PWM_BOOT_US 800
#define PWM_MIN_US 1000
#define PWM_MAX_US 2000

// ---------------- Timing ----------------
#define BOOT_TIME_MS 2500  // must >2s
#define LOOP_DELAY_MS 10   // 100hz

// ---------------- Soft Start ----------------
#define RAMP_STEP_US_UP 2
#define RAMP_STEP_US_DOWN 4

// ---------------- Variables ----------------
uint16_t pwmOutput = PWM_BOOT_US;
uint16_t pwmTarget = PWM_BOOT_US;
unsigned long bootTime;
Servo myservo;

// ---------------- Setup ----------------
void setup() {
  pinMode(PWM_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, HIGH);  // turn off LED (active LOW)

  bootTime = millis();

  // attach
  myservo.attach(PWM_PIN);

  myservo.writeMicroseconds(PWM_BOOT_US);
}

// ---------------- Main Loop ----------------
void loop() {
  if (millis() - bootTime < BOOT_TIME_MS) {
    // blink the LED while in the boot period (LED is active‑LOW)
    unsigned long t = millis() - bootTime;
    if (((t / 500) % 2) == 0)
      digitalWrite(LED_PIN, LOW);
    else
      digitalWrite(LED_PIN, HIGH);

    myservo.writeMicroseconds(PWM_BOOT_US);
    delay(LOOP_DELAY_MS);
    return;
  }
  // turn on LED after boot period
  digitalWrite(LED_PIN, LOW);

  // read ADC
  uint16_t adc = analogRead(ADC_PIN);

  // map ADC to PWM range
  pwmTarget = map(adc, 0, 1023, PWM_MIN_US, PWM_MAX_US);

  // soft ramp toward target
  if (pwmOutput < pwmTarget) {
    pwmOutput += RAMP_STEP_US_UP;
    if (pwmOutput > pwmTarget) pwmOutput = pwmTarget;
  } else if (pwmOutput > pwmTarget) {
    pwmOutput -= RAMP_STEP_US_DOWN;
    if (pwmOutput < pwmTarget) pwmOutput = pwmTarget;
  }

  myservo.writeMicroseconds(pwmOutput);

  delay(LOOP_DELAY_MS);
}